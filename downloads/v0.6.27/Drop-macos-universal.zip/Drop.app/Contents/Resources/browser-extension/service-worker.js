const chromeApi = globalThis.chrome;
const nativeHost = "com.gauravmahajan.drop";
const linkMenuId = "add-link-to-drop";
const activeImports = new Set();

async function installMenus() {
  await chromeApi.contextMenus.removeAll();
  chromeApi.contextMenus.create({
    id: linkMenuId,
    title: "Add to Drop",
    contexts: ["link"],
  });
}

async function showResult(title, message, success) {
  try {
    await chromeApi.notifications.create({
      type: "basic",
      iconUrl: chromeApi.runtime.getURL("icon.svg"),
      title,
      message,
    });
  } catch (error) {
    console.warn("Drop notification failed", error);
  }
  await chromeApi.action.setBadgeBackgroundColor({ color: success ? "#2f8f5b" : "#b64f5d" });
  await chromeApi.action.setBadgeText({ text: success ? "✓" : "!" });
  await chromeApi.action.setTitle({ title: `${title}: ${message}` });
  globalThis.setTimeout(() => {
    void chromeApi.action.setBadgeText({ text: "" });
    void chromeApi.action.setTitle({ title: "Add a directly opened file to Drop" });
  }, 8000);
}

function isDownloadableUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

function chromePdfViewerSource(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== "chrome-extension:" || url.hostname !== "mhjfbmdgcfjbbpaeojofohoefgiehjai") {
      return null;
    }
    for (const key of ["file", "url", "src"]) {
      const candidate = url.searchParams.get(key);
      if (isDownloadableUrl(candidate)) return candidate;
    }
  } catch {}
  return null;
}

function webOrigin(value) {
  try {
    const url = new URL(value);
    return isDownloadableUrl(url.href) ? url.origin : null;
  } catch {
    return null;
  }
}

function directCanvasDownloadUrl(value) {
  const url = new URL(value);
  const previewFileId = url.searchParams.get("preview");
  const folderMatch = url.pathname.match(/^\/courses\/(\d+)\/files\/folder(?:\/.*)?$/i);
  if (folderMatch && /^\d+$/.test(previewFileId ?? "")) {
    url.pathname = `/courses/${folderMatch[1]}/files/${previewFileId}/download`;
    url.search = "";
    url.searchParams.set("download_frd", "1");
    return url.href;
  }
  if (/\/(?:courses\/\d+\/)?files\/\d+\/?$/i.test(url.pathname)) {
    url.pathname = `${url.pathname.replace(/\/$/, "")}/download`;
    url.searchParams.delete("wrap");
    url.searchParams.set("download_frd", "1");
  }
  return url.href;
}

function suggestedFileName(url, title) {
  const pathName = new URL(url).pathname.split("/").filter(Boolean).at(-1) ?? "";
  const decoded = (() => {
    try {
      return decodeURIComponent(pathName);
    } catch {
      return pathName;
    }
  })();
  const source = decoded && !/^download$/i.test(decoded) && !/^\d+$/.test(decoded)
    ? decoded
    : title?.trim() || "Chrome download";
  if (/\/(?:courses\/\d+\/)?files\/\d+\/download$/i.test(new URL(url).pathname)) {
    return source.toLowerCase().endsWith(".pdf") ? source : `${source}.pdf`;
  }
  return source;
}

async function findDownloadUrl(tab) {
  const viewerSource = chromePdfViewerSource(tab?.url);
  if (viewerSource) return viewerSource;
  if (!tab?.id) return isDownloadableUrl(tab?.url) ? tab.url : null;
  try {
    const results = await chromeApi.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        if (document.contentType?.toLowerCase() === "application/pdf") return location.href;
        const selectors = [
          "a[download][href]",
          "a[href*='/files/'][href*='/download']",
          "a[href*='/files/'][href*='download_frd']",
          "a[href$='.pdf']",
          "embed[src*='.pdf']",
          "iframe[src*='.pdf']",
        ];
        for (const selector of selectors) {
          const element = document.querySelector(selector);
          const value = element?.href ?? element?.src;
          if (value) return new URL(value, location.href).href;
        }
        return location.pathname.toLowerCase().endsWith(".pdf") ? location.href : null;
      },
    });
    const result = results?.[0]?.result;
    if (isDownloadableUrl(result)) return result;
  } catch (error) {
    console.debug("Drop could not inspect the current page", error);
  }
  return null;
}

function permissionPattern(value) {
  const url = new URL(value);
  return `${url.protocol}//${url.hostname}/*`;
}

function ensureWebsiteAccess(url) {
  const request = {
    permissions: ["cookies"],
    origins: [permissionPattern(url)],
  };
  return new Promise((resolve, reject) => {
    // Chrome requires request() to be invoked directly inside the click gesture.
    // An asynchronous contains() check here causes Chrome to silently reject it.
    chromeApi.permissions.request(request, (granted) => {
      const runtimeError = chromeApi.runtime.lastError?.message;
      if (runtimeError) {
        reject(new Error(`Chrome could not request website access: ${runtimeError}`));
      } else if (!granted) {
        reject(new Error("Allow Drop to read this website's signed-in session so it can retrieve the file."));
      } else {
        resolve();
      }
    });
  });
}

async function cookieHeader(url) {
  const cookies = await chromeApi.cookies.getAll({ url });
  return cookies.map((cookie) => `${cookie.name}=${cookie.value}`).join("; ");
}

function sleep(milliseconds) {
  return new Promise((resolve) => globalThis.setTimeout(resolve, milliseconds));
}

function openNativeConnection() {
  const port = chromeApi.runtime.connectNative(nativeHost);
  let closed = false;
  let disconnectError = null;
  port.onDisconnect.addListener(() => {
    closed = true;
    disconnectError = chromeApi.runtime.lastError?.message ?? "Drop closed its Chrome connection.";
  });
  return {
    request(message) {
      return new Promise((resolve, reject) => {
        if (closed) {
          reject(new Error(disconnectError));
          return;
        }
        const onMessage = (response) => {
          port.onDisconnect.removeListener(onDisconnect);
          port.onMessage.removeListener(onMessage);
          resolve(response);
        };
        const onDisconnect = () => {
          port.onMessage.removeListener(onMessage);
          port.onDisconnect.removeListener(onDisconnect);
          reject(new Error(disconnectError ?? "Drop closed its Chrome connection."));
        };
        port.onMessage.addListener(onMessage);
        port.onDisconnect.addListener(onDisconnect);
        try {
          port.postMessage(message);
        } catch (error) {
          port.onMessage.removeListener(onMessage);
          port.onDisconnect.removeListener(onDisconnect);
          reject(error);
        }
      });
    },
    close() {
      if (!closed) port.disconnect();
    },
  };
}

async function waitForDestination(connection, requestId) {
  const deadline = Date.now() + 20 * 60 * 1000;
  while (Date.now() < deadline) {
    await sleep(500);
    const response = await connection.request({
      type: "browser_import_status",
      requestId,
    });
    if (!response?.ok) throw new Error(response?.error ?? "Drop could not prepare the browser import.");
    if (response.status === "approved") return;
    if (response.status === "cancelled") throw new Error("The browser import was cancelled in Drop.");
    if (response.status === "failed") throw new Error(response.error ?? "Drop could not prepare the browser import.");
  }
  throw new Error("The Drop destination request expired. Try adding the file again.");
}

async function beginImport(url, pageUrl, title, grantedOrigin = null) {
  if (!isDownloadableUrl(url)) {
    await showResult("Drop could not find a download", "Open the page or right-click the file link again.", false);
    return;
  }
  const downloadUrl = directCanvasDownloadUrl(url);
  if (activeImports.has(downloadUrl)) return;
  activeImports.add(downloadUrl);
  const connection = openNativeConnection();
  try {
    if (webOrigin(downloadUrl) !== grantedOrigin) await ensureWebsiteAccess(downloadUrl);
    const requestId = globalThis.crypto.randomUUID();
    const name = suggestedFileName(downloadUrl, title);
    const prepared = await connection.request({
      type: "prepare_browser_import",
      requestId,
      name,
    });
    if (!prepared?.ok) throw new Error(prepared?.error ?? "Drop could not open its destination picker.");
    await chromeApi.action.setBadgeBackgroundColor({ color: "#416a96" });
    await chromeApi.action.setBadgeText({ text: "…" });
    await chromeApi.action.setTitle({ title: "Choose the file destination in Drop" });
    await waitForDestination(connection, requestId);

    const response = await connection.request({
      type: "download_browser_file",
      requestId,
      url: downloadUrl,
      name,
      cookieHeader: await cookieHeader(downloadUrl),
      referer: isDownloadableUrl(pageUrl) ? pageUrl : downloadUrl,
      userAgent: globalThis.navigator.userAgent,
    });
    if (!response?.ok) throw new Error(response?.error ?? "Drop could not add the file.");
    await showResult("File added to Drop", "The file was saved directly to the folder you chose.", true);
  } catch (error) {
    const message = error?.message ?? "Drop could not add that file.";
    const cancelled = message.includes("cancelled in Drop");
    await showResult(cancelled ? "Import cancelled" : "Could not add to Drop", message, false);
  } finally {
    connection.close();
    activeImports.delete(downloadUrl);
  }
}

async function importFromTab(tab, contextUrl) {
  const viewerSource = chromePdfViewerSource(contextUrl) ?? chromePdfViewerSource(tab?.url);
  if (viewerSource) {
    await beginImport(viewerSource, viewerSource, tab?.title);
    return;
  }
  const pageUrl = isDownloadableUrl(contextUrl) ? contextUrl : tab?.url;
  if (isDownloadableUrl(pageUrl)) {
    const directCanvasUrl = directCanvasDownloadUrl(pageUrl);
    if (directCanvasUrl !== pageUrl) {
      await beginImport(directCanvasUrl, pageUrl, tab?.title);
      return;
    }
  }
  let grantedOrigin = null;
  if (isDownloadableUrl(pageUrl)) {
    try {
      await ensureWebsiteAccess(pageUrl);
      grantedOrigin = webOrigin(pageUrl);
    } catch (error) {
      await showResult("Website access is required", error?.message ?? "Chrome did not grant access to this website.", false);
      return;
    }
  }
  const url = await findDownloadUrl(tab);
  await beginImport(url, pageUrl, tab?.title, grantedOrigin);
}

chromeApi.runtime.onInstalled.addListener(() => void installMenus());
chromeApi.runtime.onStartup.addListener(() => void installMenus());
chromeApi.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === linkMenuId && info.linkUrl) {
    void beginImport(info.linkUrl, tab?.url, info.selectionText || tab?.title);
  }
});
chromeApi.action.onClicked.addListener((tab) => void importFromTab(tab));
