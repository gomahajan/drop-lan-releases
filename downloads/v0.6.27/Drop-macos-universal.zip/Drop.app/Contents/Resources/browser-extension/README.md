# Add to Drop

This Chrome extension asks for a Library destination first, then uses Chrome's existing signed-in website session to download the file into Drop's private temporary area. It never creates a visible file in Chrome's Downloads folder.

For a local Chrome test:

1. Quit an older Drop from its menu-bar or tray menu before replacing it.
2. Install and launch the matching Drop test build once so it registers its native messaging host.
3. Open `chrome://extensions`, enable Developer mode, and choose **Load unpacked**.
4. Select this `browser-extension` directory.
5. Right-click a file link and choose **Add to Drop**. The toolbar button is reserved for files opened directly in the browser; Drop does not offer a page-level right-click action on embedded viewers or ordinary webpages.
6. The first time you use a website, allow Drop to read that site's signed-in session. This is a one-time site permission; Drop does not ask for or store the website password.
